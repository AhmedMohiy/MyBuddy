package com.example.mybuddy.Utilities;

import android.app.Activity;
import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.support.design.widget.FloatingActionButton;
import android.view.View;
import android.view.ViewGroup;

import com.example.mybuddy.Models.Data.Memos;
import com.example.mybuddy.R;

/**
 * Created by ahmed on 03/11/16.
 */

public class Global {


    public static boolean FirstTimeOpeningApp = true;

    public static ViewGroup HomeView;

    public static FloatingActionButton fab;
    public static String[] month = new String[12];

    public static boolean firstTimeOpen = true;
    public static String TodoDay = "";
    public static String TodoMonth = "";
    public static String TodoYear = "";

    public static String yearMemo = "";
    public static String monthMemo = "";
    public static String dayMemo = "";

    public static boolean fromMemos = false;

    public static int bool = 0;

    public  static Memos memosObject;

    public static String Latitude = "0.0";
    public static String Longitude = "0.0";
    public static Context homeContext;

    public static String okOrCancel = "";
    public static int anything;


    public static boolean checkInternet(Context context)
    {

        ConnectivityManager connectivityManager = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
        boolean connect =  activeNetworkInfo != null && activeNetworkInfo.isConnected();


        return connect;
    }

    public static void InisializeMonthArray(Context context)
    {



        month[0] = context.getResources().getString(R.string.January);
        month[1] = context.getResources().getString(R.string.February);
        month[2] = context.getResources().getString(R.string.March);
        month[3] = context.getResources().getString(R.string.April);
        month[4] = context.getResources().getString(R.string.May);
        month[5] = context.getResources().getString(R.string.June);
        month[6] = context.getResources().getString(R.string.July);
        month[7] = context.getResources().getString(R.string.August);
        month[8] = context.getResources().getString(R.string.September);
        month[9] = context.getResources().getString(R.string.October);
        month[10] = context.getResources().getString(R.string.November);
        month[11] = context.getResources().getString(R.string.December);

    }
}
