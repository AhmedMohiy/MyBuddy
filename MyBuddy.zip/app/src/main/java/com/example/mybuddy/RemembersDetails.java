package com.example.mybuddy;

import android.app.Activity;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.example.mybuddy.Utilities.Global;

public class RemembersDetails extends Activity {

    TextView title;
    TextView date;
    TextView time;

    Button ok;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_remembers_details);


        title = (TextView) findViewById(R.id.reminder_details_row_title);
        date = (TextView) findViewById(R.id.reminder_details_row_date);
        time = (TextView) findViewById(R.id.reminder_details_row_time);

        ok = (Button) findViewById(R.id.reminder_details_ok_button);


        title.setText(Global.memosObject.SPECIFICATION);
        String str = Global.month[Integer.parseInt(Global.memosObject.MONTH)].substring(0,3)
                +" "+Global.memosObject.DAY+", "+Global.memosObject.YEAR;

        date.setText(str);

        time.setText(Global.memosObject.HOURS+":"+Global.memosObject.MINUTES);

        ok.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

    }
}
