package com.example.mybuddy.Models.ReceiveData;

/**
 * Created by ahmed on 04/11/16.
 */

public class CoordClass {

    public double lon = 0.0;
    public double lat = 0.0;
}
