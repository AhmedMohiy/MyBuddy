package com.example.mybuddy;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.LinearLayout;
import android.widget.ListView;

import com.example.mybuddy.Adapters.ListViewAdapter;
import com.example.mybuddy.Models.Data.Memos;
import com.example.mybuddy.Models.MyDB;
import com.example.mybuddy.Utilities.Global;

import java.util.ArrayList;

public class MemosList extends AppCompatActivity {


    MyDB db;

    String day;
    String month;
    String year;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_memos_list);

        setTitle(this.getResources().getString(R.string.Memos));



        Global.fromMemos = true;




    }

    public void create()
    {
        day = Global.dayMemo;
        month = Global.monthMemo;
        year = Global.yearMemo;

        int mm = Integer.parseInt(month);
        mm--;

        month = mm+"";

        if (month.length() == 1)
        {
            month = "0"+month;
        }

        db = new MyDB(this,null,null,1);

        ArrayList<Memos> memoses = db.getMemosByDay(day,year,month);

        ListView myList = (ListView) findViewById(R.id.List_view_reminder_Activity);

        LinearLayout layout = (LinearLayout) findViewById(R.id.reminder_Activity_layout);

        ListViewAdapter adapter = new ListViewAdapter(this,memoses);

        myList.setAdapter(adapter);

        final Animation animCycle = AnimationUtils.loadAnimation(this, R.anim.anothercycle);

        if (memoses.size() == 0)
        {
            layout.setVisibility(View.VISIBLE);
            layout.startAnimation(animCycle);
        }
        else
        {
            layout.setVisibility(View.GONE);
        }


    }

    @Override
    protected void onResume() {
        super.onResume();

        create();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.memos_list, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        int id  = item.getItemId();
        switch (id){
            case R.id.add:
                startActivity(new Intent(this, AddRemember.class));
                return true;


        }
        return super.onOptionsItemSelected(item);
    }
}
