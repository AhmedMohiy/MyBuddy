package com.example.mybuddy.Models;

import com.example.mybuddy.Models.ReceiveData.*;

import java.util.ArrayList;

/**
 * Created by ahmed on 04/11/16.
 */

public class ReceiveWeatherData {

    public CoordClass coord = new CoordClass();
    public ArrayList<WeatherClass> weather = new ArrayList<>();
    public MainClass main = new MainClass();
    public String name = "";
}
