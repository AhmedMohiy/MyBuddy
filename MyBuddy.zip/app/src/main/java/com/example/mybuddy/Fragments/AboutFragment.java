package com.example.mybuddy.Fragments;

import android.app.Fragment;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.mybuddy.R;
import com.example.mybuddy.Utilities.Global;

/**
 * Created by ahmed on 05/11/16.
 */

public class AboutFragment extends Fragment {

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.about,container,false);

        Global.fab.setVisibility(View.INVISIBLE);

        getActivity().setTitle(this.getResources().getString(R.string.About));

        return view;
    }
}
