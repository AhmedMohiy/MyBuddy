package com.example.mybuddy.Fragments;

import android.app.Fragment;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.LinearLayout;

import com.example.mybuddy.Adapters.RecycleViewHomeCustomAdapter;
import com.example.mybuddy.ChooseTodoDialog;
import com.example.mybuddy.Models.Data.Todo;
import com.example.mybuddy.Models.MyDB;
import com.example.mybuddy.R;
import com.example.mybuddy.Utilities.Global;

import java.util.ArrayList;

/**
 * Created by ahmed on 02/11/16.
 */

public class TodoHistoryFragmednt extends Fragment {

    View view;

    public RecyclerView myRecyclerView;
    public RecyclerView.Adapter myAdapter;
    public LinearLayoutManager myLayout;




    LinearLayout layout;

    MyDB db;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        view = inflater.inflate(R.layout.todo_history_fragment,container,false);


        getActivity().setTitle(this.getResources().getString(R.string.TODOList));

        setHasOptionsMenu(true);

        createsAll();

        Global.fab.setVisibility(View.INVISIBLE);
        return view;
    }

    public void createsAll()
    {
        layout = (LinearLayout) view.findViewById(R.id.todo_fragment_layout_notodolist);

        final Animation animCycle = AnimationUtils.loadAnimation(view.getContext(), R.anim.anothercycle);
        if(Global.firstTimeOpen)
        {
            Global.bool = 0;
            Global.firstTimeOpen =  false;
            layout.setVisibility(View.VISIBLE);
            startActivity(new Intent(this.getActivity(), ChooseTodoDialog.class));
        }
        else
        {
            db = new MyDB(this.getActivity(),null,null,1);
            Log.d("AnyMonth: ",Global.anything+"" );
            Log.d("Month : ",Global.TodoMonth  );
            Log.d("day : ",Global.TodoDay  );
            Log.d("Year : ",Global.TodoYear  );
            ArrayList<Todo> todoData = db.getTodo(Global.TodoDay,Global.TodoMonth,Global.TodoYear);

            if (todoData.size() > 0 )
            {

                layout.setVisibility(View.GONE);
            }
            else
            {
                layout.setVisibility(View.VISIBLE);
                layout.startAnimation(animCycle);
            }


            myAdapter = new RecycleViewHomeCustomAdapter(todoData);
            myRecyclerView = (RecyclerView) view.findViewById(R.id.todo_fragment_RecycleView) ;
            myRecyclerView.setHasFixedSize(true);
            myLayout = new LinearLayoutManager(this.getActivity());
            myLayout.setOrientation(LinearLayoutManager.VERTICAL);
            myRecyclerView.setLayoutManager(myLayout);
            myRecyclerView.setAdapter(myAdapter);

        }


    }

    @Override
    public void onResume() {
        super.onResume();

        if (!Global.firstTimeOpen)
        {
            createsAll();
        }

    }

    @Override
    public void onDestroy() {
        super.onDestroy();

        Global.firstTimeOpen = true;
    }

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        inflater.inflate(R.menu.todo_fragment_menu, menu);
        super.onCreateOptionsMenu(menu, inflater);




    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        int id =item.getItemId();

        switch (id)
        {
            case R.id.action_dialog:
                Global.bool = 0;
                startActivity(new Intent(this.getActivity(),ChooseTodoDialog.class));
                return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
