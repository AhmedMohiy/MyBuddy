package com.example.mybuddy.Adapters;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;


import com.example.mybuddy.Holders.HolderTodoHome;
import com.example.mybuddy.Models.Data.Todo;
import com.example.mybuddy.R;
import com.example.mybuddy.Utilities.Global;

import java.util.ArrayList;

/**
 * Created by ahmed on 04/11/16.
 */

public class RecycleViewHomeCustomAdapter extends RecyclerView.Adapter<HolderTodoHome> {

    Context context;
    int id;
    private ArrayList<Todo> Tododata = new ArrayList<>();

    public RecycleViewHomeCustomAdapter(ArrayList<Todo> Tododata)
    {
        this.Tododata = Tododata;
    }


    @Override
    public HolderTodoHome onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.todo_list_items_row,parent,false);
        context = parent.getContext();

        return new HolderTodoHome(view,Tododata);
    }

    @Override
    public void onBindViewHolder(final HolderTodoHome holder, int position) {


        Todo tododataObject = Tododata.get(position);

        if(tododataObject.BOOL_DONE == 0)
        {
            holder.checkBox.setChecked(false);
        }
        else
        {
            holder.checkBox.setChecked(true);
        }

        holder.title.setText(tododataObject.TITLE);
        holder.description.setText(tododataObject.DESCRIPTION);
        holder.dayName.setText(tododataObject.DAY_NAME);
        String MonthName = Global.month[Integer.parseInt(tododataObject.MONTH)];
        String mon = "";
        if (MonthName.length() > 2)
        {
            mon = MonthName.substring(0,3);
        }
        else
        {
            mon = MonthName;
        }
        String day_month = tododataObject.DAY_NUMBER+"-"+mon;

        holder.dayNumMonth.setText(day_month);



    }

    @Override
    public int getItemCount() {
        return Tododata.size();
    }
}
