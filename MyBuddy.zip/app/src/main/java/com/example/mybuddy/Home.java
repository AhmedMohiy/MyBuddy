package com.example.mybuddy;

import android.app.AlertDialog;
import android.app.FragmentManager;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.provider.Settings;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;


import com.example.mybuddy.Adapters.RecycleViewHomeCustomAdapter;
import com.example.mybuddy.Fragments.AboutFragment;
import com.example.mybuddy.Fragments.MemosFragment;
import com.example.mybuddy.Fragments.ReminderTodayFragment;
import com.example.mybuddy.Fragments.TodoHistoryFragmednt;
import com.example.mybuddy.Models.Data.Todo;
import com.example.mybuddy.Models.Data.Weather;
import com.example.mybuddy.Models.MyDB;
import com.example.mybuddy.Models.ReceiveWeatherData;
import com.example.mybuddy.Utilities.Connection;
import com.example.mybuddy.Utilities.GPSConnection;
import com.example.mybuddy.Utilities.GPSFetching;
import com.example.mybuddy.Utilities.Global;
import com.google.gson.Gson;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.concurrent.ExecutionException;

public class Home extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener {


    private String UserName = "";
    private static double lat;
    private static double lon;
    private TextView Name_Title;
    private TextView weatherTitle;
    private TextView weatherNow;
    private TextView weatherMax;
    private TextView weatherMin;
    private TextView City;

    private LinearLayout layout;
    private TextView cleckHere;

    private ImageView imageView;

    private static double Lat=0.0;
    private static double Lon=0.0;


    public RecyclerView myRecyclerView;
    public RecyclerView.Adapter myAdapter;
    public LinearLayoutManager myLayout;



    public static int dayNum ;
    public static int month ;
    public static int year ;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_home);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        Global.homeContext = this;


        final ViewGroup viewGroup = (ViewGroup) ((ViewGroup) this
                .findViewById(android.R.id.content)).getChildAt(0);

        Global.HomeView = viewGroup;

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        Global.fab = fab;
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                /*Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();*/


                startActivity(new Intent(getBaseContext(), TodoInsertDetails.class));
                overridePendingTransition(R.anim.in, R.anim.out);

            }
        });

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.setDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);




        Name_Title = (TextView) findViewById(R.id.home_name_title);



        if(Global.FirstTimeOpeningApp && !Global.checkInternet(this))
        {
            AlertDialog.Builder alert = new AlertDialog.Builder(this);

            alert.setTitle("Internet Settings");

            alert.setMessage("Internet not enabled. Please check your internet connection Or some features will not work.");

            alert.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    dialog.dismiss();
                }
            });



            alert.show();

        }

        GPSFetching gps = new GPSFetching(Home.this);


        if (Global.FirstTimeOpeningApp && !gps.CanGetLocation())
        {
            gps.showSettingsAlert(this);
        }


        Global.FirstTimeOpeningApp = false;



        if (Global.fromMemos)
        {
            Global.fromMemos = false;
            FragmentManager fragmentManager = getFragmentManager();

            fragmentManager.beginTransaction()
                    .replace(R.id.content_home,new MemosFragment())
                    .commit();
        }





        Calendar now = Calendar.getInstance();

         dayNum = now.get(Calendar.DAY_OF_MONTH);
         month = now.get(Calendar.MONTH);
         year = now.get(Calendar.YEAR);

        Log.d("Moonth:",month+"");

        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("EEE");
        Date date = new Date();
        String dayOfTheWeek = simpleDateFormat.format(date);


        TextView dateText = (TextView) findViewById(R.id.home_date_text);




        String finalDate = dayOfTheWeek + " " + Global.month[month] + " " + dayNum + ", " + year;
        dateText.setText(finalDate);



        MyDB db = new MyDB(this,null,null,1);






        layout = (LinearLayout) findViewById(R.id.todo_home_layout_notodolist);
        cleckHere = (TextView) findViewById(R.id.home_text_clickhere);


        String daystr = dayNum+"";
        String monthStr = month+"";
        String yearstr = year+"";

        if(daystr.length() == 1)
        {
            daystr = "0"+daystr;
        }

        if(monthStr.length() == 1)
        {
            monthStr = "0"+monthStr;
        }

        ArrayList<Todo> todoData = db.getTodo(daystr,monthStr,yearstr);

        if (todoData.size() > 0)
        {
            layout.setVisibility(View.GONE);
        }
        else
        {
            layout.setVisibility(View.VISIBLE);

        }


        cleckHere.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(),TodoInsertDetails.class));
                overridePendingTransition(R.anim.in, R.anim.out);

            }
        });

        myAdapter = new RecycleViewHomeCustomAdapter(todoData);
        myRecyclerView = (RecyclerView) findViewById(R.id.home_recycleview) ;
        myRecyclerView.setHasFixedSize(true);
        myLayout = new LinearLayoutManager(this.getBaseContext());
        myLayout.setOrientation(LinearLayoutManager.VERTICAL);
        myRecyclerView.setLayoutManager(myLayout);
        myRecyclerView.setAdapter(myAdapter);

//        SharedPreferences.Editor editor2 = getSharedPreferences("MyBuddyPrefrences", MODE_PRIVATE).edit();
//        editor2.putString("name", "0");
//        editor2.commit();

        SharedPreferences prefs = getSharedPreferences("MyBuddyPrefrences", MODE_PRIVATE);
        if(prefs != null)
        {
            String restoredText = prefs.getString("name", "0");
            if (restoredText.equals("0")) {

                startActivity(new Intent(this,EnterName.class));
                this.finish();

            }
            else
            {
                UserName = prefs.getString("name", "0");//"No name defined" is the default value.
                Name_Title.setText(UserName);


            }
        }
        else
        {


            SharedPreferences pref = getApplicationContext().getSharedPreferences("MyBuddyPrefrences", MODE_PRIVATE);
            SharedPreferences.Editor editor = pref.edit();
            editor.putString("name", "0");
            editor.commit();
        }


        Name_Title.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                startActivity(new Intent(v.getContext(),EnterName.class));
                finish();
            }
        });




    }



    public void CreateWeather()
    {

            weatherTitle = (TextView) findViewById(R.id.home_weather_textview_weather_title);
            weatherNow = (TextView) findViewById(R.id.home_weather_textview_big_degree);
            weatherMax = (TextView) findViewById(R.id.home_weather_textview_max_degree);
            weatherMin = (TextView) findViewById(R.id.home_weather_textview_min_degree);
            City = (TextView) findViewById(R.id.home_country_text);

            imageView = (ImageView) findViewById(R.id.home_weather_image);

            MyDB db = new MyDB(this,null,null,1);






        if (Global.checkInternet(this))
        {
            String result = "";

            GPSFetching gps = new GPSFetching(Home.this);

            if(gps.CanGetLocation())
            {
                try {
                    new GPSConnection().execute(Home.this);
                } catch (Exception e) {

                    result = "-1";
                }
            }




        }else
        {

            Weather data = db.getWeather(dayNum+"",month+"",year+"");

            if (data == null)
            {
                weatherTitle.setText("No Internet");
                weatherNow.setText("0.0"+(char) 0x00B0);
                weatherMin.setText("0.0"+(char) 0x00B0);
                weatherMax.setText("0.0"+(char) 0x00B0);


                int imageID = getResources().getIdentifier("com.example.mybuddy:drawable/" + "mark2.png", null, null);
                imageView.setImageResource(imageID);
            }
            else
            {
                weatherTitle.setText(data.main);
                weatherNow.setText(data.temp+(char) 0x00B0);
                weatherMin.setText(data.temp_min+(char) 0x00B0);
                weatherMax.setText(data.temp_max+(char) 0x00B0);
                City.setText(data.city);

                int imageID;

                if (data.main.equals("Clear"))
                {
                    imageID = getResources().getIdentifier("com.example.mybuddy:drawable/" + "art_clear", null, null);

                }
                else if(data.main.equals("Clouds"))
                {
                    imageID = getResources().getIdentifier("com.example.mybuddy:drawable/" + "art_clouds", null, null);

                }
                else if (data.main.equals("Snow"))
                {
                    imageID = getResources().getIdentifier("com.example.mybuddy:drawable/" + "art_snow", null, null);

                }
                else if (data.main.equals("Rain"))
                {
                    imageID = getResources().getIdentifier("com.example.mybuddy:drawable/" + "art_light_rain", null, null);

                }
                else
                {
                    imageID = getResources().getIdentifier("com.example.mybuddy:drawable/" + "art_fog", null, null);

                }

                imageView.setImageResource(imageID);

            }



        }









    }



    @Override
    protected void onResume() {
        super.onResume();

        CreateWeather();
        Log.d("lat and lon : " ,Lat+" | "+Lon);
        Log.d("resume","Resume");

    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.home, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.

        return super.onOptionsItemSelected(item);
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

        FragmentManager fragmentManager = getFragmentManager();

        if (id == R.id.nav_home) {
            startActivity(new Intent(this,Home.class));
            this.finish();
        } else if (id == R.id.nav_gps) {

            if (Global.checkInternet(getApplicationContext()))
            {
                startActivity(new Intent(this,Map.class));
            }
            else
            {
                AlertDialog.Builder alert = new AlertDialog.Builder(this);

                alert.setTitle("Internet Settings");

                alert.setMessage("Internet not enabled. Please check your internet connection");

                alert.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });



                alert.show();
            }



        } else if (id == R.id.nav_todo) {

            fragmentManager.beginTransaction()
                    .replace(R.id.content_home,new TodoHistoryFragmednt())
                    .commit();

        } else if (id == R.id.nav_remembers) {

            fragmentManager.beginTransaction()
                    .replace(R.id.content_home,new MemosFragment())
                    .commit();

        } else if (id == R.id.nav_about) {

            fragmentManager.beginTransaction()
                    .replace(R.id.content_home,new AboutFragment())
                    .commit();

        }
        else if(id == R.id.nav_RemiderToday)
        {
            fragmentManager.beginTransaction()
                    .replace(R.id.content_home,new ReminderTodayFragment())
                    .commit();

        }
        else if (id == R.id.nav_exit) {

            finish();
        }

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }
}
