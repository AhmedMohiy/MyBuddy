package com.example.mybuddy.Models.Data;

/**
 * Created by ahmed on 04/11/16.
 */

public class Memos  {

    public  int ID;
    public  String DAY ;
    public  String MONTH ;
    public  String YEAR ;
    public  String SPECIFICATION;
    public  String HOURS ;
    public  String MINUTES ;
}
