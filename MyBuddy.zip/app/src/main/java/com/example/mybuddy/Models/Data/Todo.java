package com.example.mybuddy.Models.Data;

/**
 * Created by ahmed on 04/11/16.
 */

public class Todo {

    public int ID;
    public String TITLE;
    public String DESCRIPTION ;
    public String DAY_NUMBER;
    public String DAY_NAME;
    public String MONTH ;
    public String YEAR ;
    public int BOOL_DONE;


}
