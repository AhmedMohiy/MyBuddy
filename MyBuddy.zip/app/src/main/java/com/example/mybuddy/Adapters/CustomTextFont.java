package com.example.mybuddy.Adapters;

import android.content.Context;
import android.graphics.Typeface;
import android.util.AttributeSet;
import android.widget.TextView;

/**
 * Created by ahmed on 05/11/16.
 */

public class CustomTextFont extends TextView {

    public CustomTextFont(Context context, AttributeSet attrs)
    {
        super(context,attrs);
        this.setTypeface(Typeface.createFromAsset(context.getAssets(),"Fonts/Jurassic.ttf"));
    }
}
