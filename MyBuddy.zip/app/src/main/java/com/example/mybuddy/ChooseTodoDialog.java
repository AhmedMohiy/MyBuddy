package com.example.mybuddy;

import android.app.Activity;
import android.content.Context;
import android.content.res.Resources;
import android.graphics.Typeface;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;


import com.example.mybuddy.Adapters.SpinnerCustomAdapter;
import com.example.mybuddy.Adapters.SpinnerToDoHistoryCustomAdapter;
import com.example.mybuddy.Utilities.Global;

import java.util.ArrayList;

public class ChooseTodoDialog extends Activity {

    SpinnerToDoHistoryCustomAdapter adapterDay;
    SpinnerToDoHistoryCustomAdapter adapterMonth;
    SpinnerToDoHistoryCustomAdapter adapterYear;


    LinearLayout layout;


    Context context;

    Spinner spinerDay;
    Spinner spinnerMonyh;
    Spinner spinnerYear;

    TextView day_text;
    TextView month_text;
    TextView year_text;

    Button done;

    String day = "";
    String month = "";
    String year = "";


    ArrayList<String> days = new ArrayList<>();
    ArrayList<String> months = new ArrayList<>();
    ArrayList<String> years = new ArrayList<>();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_choose_todo_dialog);

        context = this;


        spinerDay = (Spinner) findViewById(R.id.spinner_day);
        spinnerMonyh = (Spinner) findViewById(R.id.spinner_month);
        spinnerYear = (Spinner) findViewById(R.id.spinner_year);

        day_text = (TextView) findViewById(R.id.day_text);
        month_text = (TextView) findViewById(R.id.month_text);
        year_text = (TextView) findViewById(R.id.year_text);

        done = (Button) findViewById(R.id.done_button);

        TextView title = (TextView) findViewById(R.id.choose_title);
        Typeface typeface = Typeface.createFromAsset(getAssets(),"Fonts/Montague.ttf");
        title.setTypeface(typeface);

        layout = (LinearLayout) findViewById(R.id.todo_dialog_layout);

        if (Global.bool == 0)
        {
            layout.setVisibility(View.VISIBLE);
        }
        else
        {
            layout.setVisibility(View.INVISIBLE);
        }

        for (int i = 1 ; i < 32 ; i++)
        {
            String str = String.valueOf(i);


            if (str.length() == 1)
            {
                str = "0"+str;
            }

            days.add(str);
        }

        months = new ArrayList<>();

        for (int i = 1 ; i < 13 ; i++)
        {
            String str = i+"";


            if (str.length() == 1)
            {
                str = "0"+str;
            }

            months.add(str);
        }


        for (int i = 2016 ; i < 2050 ; i++)
        {
            String str = i+"";


            years.add(str);
        }


        Resources resources = getResources();

        adapterDay = new SpinnerToDoHistoryCustomAdapter(this,R.layout.spinner_layout,days,resources);
        adapterMonth = new SpinnerToDoHistoryCustomAdapter(this,R.layout.spinner_layout,months,resources);
        adapterYear = new SpinnerToDoHistoryCustomAdapter(this,R.layout.spinner_layout,years,resources);



        spinerDay.setAdapter(adapterDay);
        spinnerMonyh.setAdapter(adapterMonth);
        spinnerYear.setAdapter(adapterYear);


        spinerDay.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

                day = parent.getItemAtPosition(position).toString();

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });


        spinnerMonyh.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

                month = parent.getItemAtPosition(position).toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });


        spinnerYear.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

                year = parent.getItemAtPosition(position).toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });






        done.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(day.length() > 0 &&
                        month.length() > 0 &&
                        year.length() > 0 && Global.bool == 0)
                {



                    Global.firstTimeOpen = false;
                    Global.TodoDay = day;
                    Global.anything = Integer.parseInt(month);
                    int monthInt = Integer.parseInt(month);
                    monthInt--;
                    month = String.valueOf(monthInt);

                    if (month.length() == 1)
                    {
                        month = "0"+month;
                    }
                    Global.TodoMonth = month;
                    Global.TodoYear = year;


                    ((Activity) context).finish();
                }
                else if (month.length() > 0 &&
                        year.length() > 0 && Global.bool == 1)
                {


                    Global.yearMemo = year;
                    Global.monthMemo = month;
                    ((Activity) context).finish();
                }
                else
                {


                    if (Global.bool == 0)
                    {
                        day_text.setBackground(day.length() == 0?

                                getDrawable(R.drawable.error):
                                getDrawable(R.color.transparent)
                        );
                    }




                    month_text.setBackground(month.length() == 0?

                            getDrawable(R.drawable.error):
                            getDrawable(R.color.transparent)
                    );

                    year_text.setBackground(year.length() == 0?

                            getDrawable(R.drawable.error):
                            getDrawable(R.color.transparent)
                    );


                }
            }
        });




    }
}
