package com.example.mybuddy.Models.ReceiveData;

/**
 * Created by ahmed on 04/11/16.
 */

public class WeatherClass {

    public String main = "";
}
