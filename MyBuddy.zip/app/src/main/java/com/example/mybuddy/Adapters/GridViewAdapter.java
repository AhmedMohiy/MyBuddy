package com.example.mybuddy.Adapters;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.mybuddy.Fragments.MemosFragment;
import com.example.mybuddy.Models.Data.Memos;
import com.example.mybuddy.R;

import java.util.ArrayList;

/**
 * Created by ahmed on 04/11/16.
 */

public class GridViewAdapter extends BaseAdapter {


    private Activity context;
    LayoutInflater inflater;

    ArrayList<Memos> memos = new ArrayList<>();

    public GridViewAdapter(Activity context , ArrayList<Memos> memoses)
    {
        this.context = context;
        memos = memoses;
        inflater = (LayoutInflater) this.context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

    }

    @Override
    public int getCount() {
        return 31;
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {


        TextView text;
        ImageView image;

        if (convertView == null) {
            convertView = inflater.inflate(R.layout.gridview_row, null);
        }

        text = (TextView) convertView.findViewById(R.id.gridview_row_text);
        image = (ImageView) convertView.findViewById(R.id.gridview_row_image);


        int number = position+1;
        String str = String.valueOf(number);
        if(str.length() == 1)
        {
            str = "0"+str;
        }
        text.setText(str);

        boolean check = false;
        for (int i =0 ; i<memos.size() ; i++)
        {
            if (memos.get(i).DAY.equals(str))
            {
                image.setImageResource(R.drawable.clear);
                check = true;
                break;
            }
        }

        if (check == false)
        {
            image.setImageResource(R.drawable.f);
        }





        return convertView;
    }
}
