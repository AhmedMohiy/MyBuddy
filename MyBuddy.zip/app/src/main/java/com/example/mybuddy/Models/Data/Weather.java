package com.example.mybuddy.Models.Data;

/**
 * Created by ahmed on 04/11/16.
 */

public class Weather {

    public int ID;
    public String DAY ;
    public String MONTH ;
    public String YEAR;
    public String lon ;
    public String lat ;
    public String main ;
    public String city;
    public String temp ;
    public String temp_min ;
    public String temp_max ;
}
