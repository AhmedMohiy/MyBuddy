package com.example.mybuddy.Holders;

import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.CheckBox;
import android.widget.TextView;


import com.example.mybuddy.Models.Data.Todo;
import com.example.mybuddy.Models.MyDB;
import com.example.mybuddy.R;

import java.util.ArrayList;

/**
 * Created by ahmed on 04/11/16.
 */

public class HolderTodoHome extends RecyclerView.ViewHolder implements View.OnClickListener {


    public CheckBox checkBox;
    public TextView title;
    public TextView description;
    public TextView dayName;
    public TextView dayNumMonth;
    int id;

    View myvi;

    ArrayList<Todo> Tododata = new ArrayList<>();


    public HolderTodoHome(View view, ArrayList<Todo> Tododata)
    {
        super(view);
        view.setOnClickListener(this);

        this.Tododata = Tododata;

        checkBox = (CheckBox) view.findViewById(R.id.checkBox);
        title = (TextView) view.findViewById(R.id.todo_row_title);
        description = (TextView) view.findViewById(R.id.todo_row_description);
        dayName = (TextView) view.findViewById(R.id.todo_row_day_name);
        dayNumMonth = (TextView) view.findViewById(R.id.todo_row_daynum_month);

    }


    @Override
    public void onClick(View v) {


        Todo tododataObject = Tododata.get(getPosition());
        id = tododataObject.ID;
        myvi = v;



        MyDB db = new MyDB(v.getContext(),null,null,1);

        db.updateTodo(tododataObject.ID,checkBox.isChecked());




    }
}
