package com.example.mybuddy.Models;

/**
 * Created by ahmed on 03/11/16.
 */

public class ToDoContract {

    public static final String TABLE_TODO = "ToDo";
    public static final String ID = "ID";
    public static final String TITLE = "Title";
    public static final String DESCRIPTION = "Description";
    public static final String DAY_NUMBER = "DayNum";
    public static final String DAY_NAME = "DayName";
    public static final String MONTH = "Month";
    public static final String YEAR = "Year";
    public static final String BOOL_DONE = "Done";



}
