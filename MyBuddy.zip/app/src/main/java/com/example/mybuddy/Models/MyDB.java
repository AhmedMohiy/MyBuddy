package com.example.mybuddy.Models;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.example.mybuddy.Models.Data.Memos;
import com.example.mybuddy.Models.Data.Todo;
import com.example.mybuddy.Models.Data.Weather;

import java.util.ArrayList;

/**
 * Created by ahmed on 03/11/16.
 */

public class MyDB extends SQLiteOpenHelper {

    public static final int DATABASE_VERSION = 1;
    public static final String DATABASE_NAME = "MyBuddy.db";

    public MyDB(Context context, String name, SQLiteDatabase.CursorFactory factory, int version) {
        super(context, DATABASE_NAME, factory, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {


        //Creation of table Reminder
        String query = "CREATE TABLE "+ ReminderContract.TABLE_REMINDER + " ( "
                + ReminderContract.ID + " INTEGER PRIMARY KEY AUTOINCREMENT , "
                + ReminderContract.DAY + " TEXT, "
                + ReminderContract.MONTH + " TEXT, "
                + ReminderContract.YEAR + " TEXT, "
                + ReminderContract.SPECIFICATION + " TEXT, "
                + ReminderContract.HOURS + " TEXT, "
                + ReminderContract.MINUTES + " TEXT "
                +");";

        db.execSQL(query);

        //Creation of table ToDoTable

         query = "CREATE TABLE "+ ToDoContract.TABLE_TODO + " ( "
                + ToDoContract.ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + ToDoContract.TITLE + " TEXT, "
                + ToDoContract.DESCRIPTION + " TEXT, "
                + ToDoContract.DAY_NUMBER + " TEXT, "
                + ToDoContract.DAY_NAME + " TEXT, "
                + ToDoContract.MONTH + " TEXT, "
                + ToDoContract.YEAR + " TEXT, "
                 +ToDoContract.BOOL_DONE + " INTEGER "
                +");";

        db.execSQL(query);


        //Creation of table WEATHER table

         query = "CREATE TABLE "+ weatherContract.TABLE_WEATHER + " ( "
                + weatherContract.ID + " INTEGER PRIMARY KEY  AUTOINCREMENT , "
                + weatherContract.DAY + " TEXT, "
                + weatherContract.MONTH + " TEXT, "
                + weatherContract.YEAR + " TEXT, "
                + weatherContract.LAT + " TEXT, "
                + weatherContract.LON + " TEXT, "
                + weatherContract.CITY + " TEXT, "
                + weatherContract.WEATHER_MAIN + " TEXT, "
                + weatherContract.TEMP_MAX + " TEXT, "
                 + weatherContract.TEMP_MIN + " TEXT, "
                 + weatherContract.TEMP_NOW + " TEXT "
                +");";

        db.execSQL(query);


    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }

    public Weather getWeather(String day, String month, String year)
    {
        Weather data = null;
        SQLiteDatabase db = getWritableDatabase();

        String query = "SELECT * FROM " + weatherContract.TABLE_WEATHER + " WHERE "
                + weatherContract.DAY + "=" + day
                + " AND " + weatherContract.MONTH +"="+month
                + " AND " + weatherContract.YEAR+"="+year;

        Cursor cursor = db.rawQuery(query,null);

        cursor.moveToFirst();

        while (!cursor.isAfterLast())
        {
            data = new Weather();

            data.ID = cursor.getInt(cursor.getColumnIndex(weatherContract.ID));
            data.DAY = cursor.getString(cursor.getColumnIndex(weatherContract.DAY));
            data.MONTH = cursor.getString(cursor.getColumnIndex(weatherContract.MONTH));
            data.YEAR = cursor.getString(cursor.getColumnIndex(weatherContract.YEAR));
            data.lat = cursor.getString(cursor.getColumnIndex(weatherContract.LAT));
            data.lon = cursor.getString(cursor.getColumnIndex(weatherContract.LON));
            data.city = cursor.getString(cursor.getColumnIndex(weatherContract.CITY));
            data.main = cursor.getString(cursor.getColumnIndex(weatherContract.WEATHER_MAIN));
            data.temp = cursor.getString(cursor.getColumnIndex(weatherContract.TEMP_NOW));
            data.temp_min = cursor.getString(cursor.getColumnIndex(weatherContract.TEMP_MIN));
            data.temp_max = cursor.getString(cursor.getColumnIndex(weatherContract.TEMP_MAX));


            cursor.moveToNext();

        }

        db.close();
        return data;
    }

    public void insertWeather(String day, String month, String year, String Lat, String Lon,ReceiveWeatherData data)
    {
        Weather newdata = getWeather(day,month ,year);

        SQLiteDatabase db = getWritableDatabase();

        ContentValues dataValues = new ContentValues();


        if(newdata == null)
        {
            dataValues.put(weatherContract.DAY,day);
            dataValues.put(weatherContract.MONTH,month);
            dataValues.put(weatherContract.YEAR,year);
            dataValues.put(weatherContract.LAT,Lat);
            dataValues.put(weatherContract.LON,Lon);
            dataValues.put(weatherContract.CITY,data.name);
            dataValues.put(weatherContract.WEATHER_MAIN,data.weather.get(0).main);
            dataValues.put(weatherContract.TEMP_NOW,data.main.temp);
            dataValues.put(weatherContract.TEMP_MIN,data.main.temp_min);
            dataValues.put(weatherContract.TEMP_MAX,data.main.temp_max);

            db.insert(weatherContract.TABLE_WEATHER,null,dataValues);

            db.close();

        }else
        {
            dataValues.put(weatherContract.WEATHER_MAIN,data.weather.get(0).main);
            dataValues.put(weatherContract.LAT,Lat);
            dataValues.put(weatherContract.LON,Lon);
            dataValues.put(weatherContract.CITY,data.name);
            dataValues.put(weatherContract.TEMP_NOW,data.main.temp);
            dataValues.put(weatherContract.TEMP_MIN,data.main.temp_min);
            dataValues.put(weatherContract.TEMP_MAX,data.main.temp_max);

            db.update(weatherContract.TABLE_WEATHER,dataValues,weatherContract.ID+"="+newdata.ID,null);
            db.close();


        }


    }

    public void updateTodo(int id,boolean checked)
    {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues dataValues = new ContentValues();

        if (checked == true)
        {
            dataValues.put(ToDoContract.BOOL_DONE,1);
        }
        else
        {
            dataValues.put(ToDoContract.BOOL_DONE,0);
        }

        db.update(ToDoContract.TABLE_TODO,dataValues,ToDoContract.ID+"="+id,null);
        db.close();


    }

    public ArrayList<Todo> getTodo(String day,String month,String year)
    {
        Todo todoObject = new Todo();
        ArrayList<Todo> todoList = new ArrayList<>();


        SQLiteDatabase db = getWritableDatabase();

        String query = "SELECT * FROM " + ToDoContract.TABLE_TODO + " WHERE "
                + ToDoContract.DAY_NUMBER + " = " + "'"+day+"'"
                + " AND " + ToDoContract.MONTH +" = "+"'"+month+"'"
                + " AND " + ToDoContract.YEAR+" = "+"'"+year+"'";

        Cursor cursor = db.rawQuery(query,null);

        cursor.moveToFirst();

        while (!cursor.isAfterLast())
        {

            todoObject = new Todo();

            todoObject.ID = cursor.getInt(cursor.getColumnIndex(ToDoContract.ID));
            todoObject.TITLE = cursor.getString(cursor.getColumnIndex(ToDoContract.TITLE));
            todoObject.DESCRIPTION = cursor.getString(cursor.getColumnIndex(ToDoContract.DESCRIPTION));
            todoObject.DAY_NUMBER = cursor.getString(cursor.getColumnIndex(ToDoContract.DAY_NUMBER));
            todoObject.DAY_NAME = cursor.getString(cursor.getColumnIndex(ToDoContract.DAY_NAME));
            todoObject.MONTH = cursor.getString(cursor.getColumnIndex(ToDoContract.MONTH));
            todoObject.YEAR = cursor.getString(cursor.getColumnIndex(ToDoContract.YEAR));
            todoObject.BOOL_DONE = cursor.getInt(cursor.getColumnIndex(ToDoContract.BOOL_DONE));



            todoList.add(todoObject);

            cursor.moveToNext();

        }


        db.close();

        return todoList;
    }


    public void InsertTodo(Todo todoObject)
    {
        SQLiteDatabase db = getWritableDatabase();

        ContentValues dataValues = new ContentValues();


        dataValues.put(ToDoContract.TITLE,todoObject.TITLE);
        dataValues.put(ToDoContract.DESCRIPTION,todoObject.DESCRIPTION);
        dataValues.put(ToDoContract.DAY_NUMBER,todoObject.DAY_NUMBER);
        dataValues.put(ToDoContract.DAY_NAME,todoObject.DAY_NAME);
        dataValues.put(ToDoContract.MONTH,todoObject.MONTH);
        dataValues.put(ToDoContract.YEAR,todoObject.YEAR);
        dataValues.put(ToDoContract.BOOL_DONE,todoObject.BOOL_DONE);

        db.insert(ToDoContract.TABLE_TODO,null,dataValues);

        db.close();



    }


    public ArrayList<Memos> getMemos(String year,String month)
    {
        ArrayList<Memos> memoses = new ArrayList<>();
        Memos memosObject = new Memos();

        SQLiteDatabase db = getWritableDatabase();

        String query = "SELECT * FROM " + ReminderContract.TABLE_REMINDER + " WHERE "
                + ReminderContract.MONTH + " = " + "'"+month+"'"
                + " AND " + ReminderContract.YEAR +" = "+"'"+year+"'";

        Cursor cursor = db.rawQuery(query,null);

        cursor.moveToFirst();

        while (!cursor.isAfterLast())
        {
            memosObject = new Memos();

            memosObject.ID = cursor.getInt(cursor.getColumnIndex(ReminderContract.ID));
            memosObject.DAY = cursor.getString(cursor.getColumnIndex(ReminderContract.DAY));
            memosObject.MONTH = cursor.getString(cursor.getColumnIndex(ReminderContract.MONTH));
            memosObject.YEAR = cursor.getString(cursor.getColumnIndex(ReminderContract.YEAR));
            memosObject.SPECIFICATION = cursor.getString(cursor.getColumnIndex(ReminderContract.SPECIFICATION));
            memosObject.HOURS = cursor.getString(cursor.getColumnIndex(ReminderContract.HOURS));
            memosObject.MINUTES = cursor.getString(cursor.getColumnIndex(ReminderContract.MINUTES));

            memoses.add(memosObject);

            cursor.moveToNext();


        }

        db.close();

        return memoses;
    }

    public void InsertMemo(Memos memos)
    {
        SQLiteDatabase db = getWritableDatabase();

        ContentValues dataValues = new ContentValues();

        dataValues.put(ReminderContract.DAY,memos.DAY);
        dataValues.put(ReminderContract.MONTH,memos.MONTH);
        dataValues.put(ReminderContract.YEAR,memos.YEAR);
        dataValues.put(ReminderContract.SPECIFICATION,memos.SPECIFICATION);
        dataValues.put(ReminderContract.HOURS,memos.HOURS);
        dataValues.put(ReminderContract.MINUTES,memos.MINUTES);

        db.insert(ReminderContract.TABLE_REMINDER,null,dataValues);

        db.close();
    }

    public ArrayList<Memos> getMemosByDay(String day,String year,String month)
    {
        ArrayList<Memos> memoses = new ArrayList<>();
        Memos memosObject = new Memos();

        SQLiteDatabase db = getWritableDatabase();

        String query = "SELECT * FROM " + ReminderContract.TABLE_REMINDER + " WHERE "
                + ReminderContract.MONTH + " = " + "'"+month+"'"
                + " AND " + ReminderContract.YEAR +" = "+"'"+year+"'"
                + " AND " + ReminderContract.DAY +" = "+"'"+day+"'";

        Cursor cursor = db.rawQuery(query,null);

        cursor.moveToFirst();

        while (!cursor.isAfterLast())
        {
            memosObject = new Memos();

            memosObject.ID = cursor.getInt(cursor.getColumnIndex(ReminderContract.ID));
            memosObject.DAY = cursor.getString(cursor.getColumnIndex(ReminderContract.DAY));
            memosObject.MONTH = cursor.getString(cursor.getColumnIndex(ReminderContract.MONTH));
            memosObject.YEAR = cursor.getString(cursor.getColumnIndex(ReminderContract.YEAR));
            memosObject.SPECIFICATION = cursor.getString(cursor.getColumnIndex(ReminderContract.SPECIFICATION));
            memosObject.HOURS = cursor.getString(cursor.getColumnIndex(ReminderContract.HOURS));
            memosObject.MINUTES = cursor.getString(cursor.getColumnIndex(ReminderContract.MINUTES));

            memoses.add(memosObject);

            cursor.moveToNext();


        }

        db.close();

        return memoses;
    }


}
