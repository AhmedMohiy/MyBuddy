package com.example.mybuddy.Fragments;

import android.app.Fragment;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.GridView;
import android.widget.TextView;


import com.example.mybuddy.Adapters.GridViewAdapter;
import com.example.mybuddy.AddRemember;
import com.example.mybuddy.ChooseTodoDialog;
import com.example.mybuddy.MemosList;
import com.example.mybuddy.Models.Data.Memos;
import com.example.mybuddy.Models.Data.Todo;
import com.example.mybuddy.Models.MyDB;
import com.example.mybuddy.R;
import com.example.mybuddy.RemembersDetails;
import com.example.mybuddy.Utilities.Global;

import java.util.ArrayList;
import java.util.Calendar;

/**
 * Created by ahmed on 04/11/16.
 */

public class MemosFragment extends Fragment {

    View view;
    TextView year;
    TextView month;

    ArrayList<Memos> memoses;



    MyDB db;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.memos_fragment,container,false);

        Global.fab.setVisibility(View.INVISIBLE);

        getActivity().setTitle(this.getResources().getString(R.string.Remembers));
        setHasOptionsMenu(true);


        Calendar now = Calendar.getInstance();

        year = (TextView) view.findViewById(R.id.memos_year_text);
        month = (TextView) view.findViewById(R.id.memos_month_text);

        int monthNow = now.get(Calendar.MONTH);
        int yearNow = now.get(Calendar.YEAR);

        monthNow++;
        String _m;
        String _y = yearNow+"";

        if ((monthNow+"").length() == 1)
        {
            _m  = "0" + monthNow;
        }
        else
        {
            _m = monthNow+"";
        }

        year.setText(_y);
        month.setText(_m);

        Global.yearMemo = _y;
        Global.monthMemo = _m;

        createall();

        return view;
    }


    public void createall()
    {
        year = (TextView) view.findViewById(R.id.memos_year_text);
        month = (TextView) view.findViewById(R.id.memos_month_text);

        year.setText(Global.yearMemo);
        month.setText(Global.monthMemo);

        int mm = Integer.parseInt(Global.monthMemo);
        mm--;

        String mmStr = mm+"";

        if (mmStr.length() == 1)
        {
            mmStr = "0"+mmStr;
        }

        db = new MyDB(this.getActivity(),null,null,1);

        memoses = db.getMemos(Global.yearMemo,mmStr);

        GridView myGridView = (GridView) view.findViewById(R.id.gridview);
        myGridView.setAdapter(new GridViewAdapter(this.getActivity(),memoses));

        myGridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
//                Toast.makeText(view.getContext(),position+1+"",Toast.LENGTH_SHORT).show();
                boolean check = false;
                int number = position+1;
                String str = String.valueOf(number);
                if(str.length() == 1)
                {
                    str = "0"+str;
                }


                Global.dayMemo = str;


                for (int i=0;i<memoses.size();i++)
                {


                    if (memoses.get(i).DAY.equals(str))
                    {
                        Global.memosObject = new Memos();
                        Global.memosObject = memoses.get(i);
                        check = true;
                        break;
                    }
                }

//                if (check)
//                {
//                    startActivity(new Intent(view.getContext(), RemembersDetails.class));
//                }
//                else
//                {
//                    startActivity(new Intent(view.getContext(), AddRemember.class));
//
//                }

                startActivity(new Intent(view.getContext(), MemosList.class));
            }
        });











    }

    @Override
    public void onResume() {
        super.onResume();

        createall();
    }

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        inflater.inflate(R.menu.remembers_menu, menu);
        super.onCreateOptionsMenu(menu, inflater);




    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        int id =item.getItemId();

        switch (id)
        {
            case R.id.remember_menu_action_dialog:
                Global.bool = 1;
                startActivity(new Intent(view.getContext(), ChooseTodoDialog.class));
                return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
