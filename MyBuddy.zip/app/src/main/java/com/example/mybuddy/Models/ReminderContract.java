package com.example.mybuddy.Models;

/**
 * Created by ahmed on 03/11/16.
 */

public class ReminderContract {

    public static final String TABLE_REMINDER = "Reminder";
    public static final String ID = "ID";
    public static final String DAY = "Day";
    public static final String MONTH = "Month";
    public static final String YEAR = "Year";
    public static final String SPECIFICATION = "Specification";
    public static final String HOURS = "Hours";
    public static final String MINUTES = "Minutes";


}
