package com.example.mybuddy.Models;

/**
 * Created by ahmed on 03/11/16.
 */

public class weatherContract {

    public static final String TABLE_WEATHER = "Weather";
    public static final String ID = "ID";
    public static final String DAY = "Day";
    public static final String MONTH = "Month";
    public static final String YEAR = "Year";
    public static final String LAT = "Lat";
    public static final String LON = "Lon";
    public static final String CITY = "City";
    public static final String WEATHER_MAIN = "WeatherMain";
    public static final String TEMP_MAX = "TempMax";
    public static final String TEMP_MIN = "TempMin";
    public static final String TEMP_NOW = "TempNow";



}
