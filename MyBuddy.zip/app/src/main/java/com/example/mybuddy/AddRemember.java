package com.example.mybuddy;

import android.app.Activity;
import android.content.res.Resources;
import android.graphics.Typeface;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;

import com.example.mybuddy.Adapters.SpinnerMemoCustomAdapter;
import com.example.mybuddy.Models.Data.Memos;
import com.example.mybuddy.Models.MyDB;
import com.example.mybuddy.Utilities.Global;

import java.util.ArrayList;

public class AddRemember extends Activity {


    SpinnerMemoCustomAdapter adapterHours;
    SpinnerMemoCustomAdapter adapterMinutes;

    AutoCompleteTextView details;
    Spinner hours;
    Spinner minutes;

    Button ok;
    Button cancel;

    String hoursStr = "";
    String minutesStr = "";

    MyDB db;

    ArrayList<String> hoursArr = new ArrayList<>();
    ArrayList<String> minutesArr = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_remember);

        details = (AutoCompleteTextView) findViewById(R.id.add_reminder_memo);
        ok = (Button) findViewById(R.id.add_reminder_ok_button);
        cancel = (Button) findViewById(R.id.add_reminder_cancel_button);

        hours = (Spinner) findViewById(R.id.add_reminder_spinner_hours);
        minutes = (Spinner) findViewById(R.id.add_reminder_spinner_minutes);

        TextView textView = (TextView) findViewById(R.id.add_title);
        Typeface typeface = Typeface.createFromAsset(getAssets(),"Fonts/PoloBrush.ttf");
        textView.setTypeface(typeface);


        for (int i = 0 ; i < 25 ; i++)
        {
            String str = i+"";

            if (str.length() == 1)
            {
                str = "0"+str;
            }

            hoursArr.add(str);
        }


        for (int i = 0 ; i < 60 ; i++)
        {
            String str = i+"";

            if (str.length() == 1)
            {
                str = "0"+str;
            }

            minutesArr.add(str);
        }


        Resources resources = getResources();

        adapterHours = new SpinnerMemoCustomAdapter(this,R.layout.spinner_layout,hoursArr,resources);
        adapterMinutes = new SpinnerMemoCustomAdapter(this,R.layout.spinner_layout,minutesArr,resources);

        hours.setAdapter(adapterHours);
        minutes.setAdapter(adapterMinutes);

        hours.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                hoursStr = parent.getItemAtPosition(position).toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        minutes.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                minutesStr = parent.getItemAtPosition(position).toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        db = new MyDB(this.getApplicationContext(),null,null,1);

        ok.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(details.getText().length() > 0 &&
                        hoursStr.length() > 0 &&
                        minutesStr.length() > 0)
                {
                    Memos memos = new Memos();

                    memos.DAY = Global.dayMemo;

                    int mm = Integer.parseInt(Global.monthMemo);
                    mm--;
                    String mmStr = mm+"";

                    if (mmStr.length() == 1)
                    {
                        mmStr = "0"+mmStr;
                    }
                    memos.MONTH = mmStr;
                    memos.YEAR = Global.yearMemo;

                    memos.SPECIFICATION = details.getText().toString();
                    memos.HOURS = hoursStr;
                    memos.MINUTES = minutesStr;

                    db.InsertMemo(memos);

                    ((Activity)v.getContext()).finish();

                }

            }
        });


        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ((Activity)v.getContext()).finish();
            }
        });

    }
}
