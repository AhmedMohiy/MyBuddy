package com.example.mybuddy.Adapters;

import android.app.Activity;
import android.content.Context;
import android.content.res.Resources;
import android.support.annotation.NonNull;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import com.example.mybuddy.AddRemember;
import com.example.mybuddy.ChooseTodoDialog;
import com.example.mybuddy.R;

import java.util.ArrayList;

/**
 * Created by ahmed on 04/11/16.
 */

public class SpinnerMemoCustomAdapter extends ArrayAdapter<String> {

    private Activity activity;
    private ArrayList<String> data;
    public Resources res;
    LayoutInflater inflater;

    public SpinnerMemoCustomAdapter(AddRemember addRemember, int textviewResorceID, ArrayList<String> data2, Resources resources)
    {
        super(addRemember,textviewResorceID,data2);

        activity = addRemember;
        this.data = new ArrayList<>();
        this.data = data2;
        res = resources;

        inflater = (LayoutInflater) activity.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public View getDropDownView(int position, View convertView, ViewGroup parent) {
        return getCustomView(position,convertView,parent);
    }

    @NonNull
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        return getCustomView(position,convertView,parent);
    }

    public View getCustomView(int position, View convertView, ViewGroup parent)
    {
        View view = inflater.inflate(R.layout.spinner_layout,parent,false);

        TextView text = (TextView) view.findViewById(R.id.text);

        text.setText(data.get(position));

        return  view;
    }
}
