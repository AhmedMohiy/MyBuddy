package com.example.mybuddy.Utilities;

import android.Manifest;
import android.app.AlertDialog;
import android.app.Service;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Build;
import android.os.Bundle;
import android.os.IBinder;
import android.provider.Settings;
import android.support.annotation.Nullable;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.util.Log;

import com.example.mybuddy.Home;

/**
 * Created by ahmed on 03/11/16.
 */

public class GPSFetching extends Service implements LocationListener {

    private final Context myContext;

    boolean isGpsEnabled = false;
    boolean isNetworkEnabled = false;
    boolean canGetLocation = false;

    Location location;

    private static double Lattetude;
    private static double Longitude;

    private static final long distance_updates = 100;
    private static final long time_updates = 1000 * 60 * 1;

    protected LocationManager locationManager;

    public GPSFetching(Context context) {
        this.myContext = context;
        getLocation();
    }

    public Location getLocation() {

        if ( Build.VERSION.SDK_INT >= 21 &&
                ContextCompat.checkSelfPermission( myContext, android.Manifest.permission.ACCESS_FINE_LOCATION ) != PackageManager.PERMISSION_GRANTED &&
                ContextCompat.checkSelfPermission( myContext, android.Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            return location;
        }

        try {

            locationManager = (LocationManager) myContext.getSystemService(LOCATION_SERVICE);
            isGpsEnabled = locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER);
            isNetworkEnabled = locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER);



            if (!isGpsEnabled && !isNetworkEnabled) {

            } else {
                this.canGetLocation = true;
                if (isNetworkEnabled) {
                    locationManager.requestLocationUpdates(
                            LocationManager.NETWORK_PROVIDER,
                            time_updates,
                            distance_updates, this);

                    if (locationManager != null) {

                        location = locationManager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);

                        if (location != null) {

                            Lattetude = location.getLatitude();
                            Longitude = location.getLongitude();

                        }
                    }
                }


                if (isGpsEnabled) {
                    if (location == null) {
                        locationManager.requestLocationUpdates(
                                LocationManager.GPS_PROVIDER,
                                time_updates,
                                distance_updates, this);


                        if (locationManager != null) {


                            location = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);



                            if (location != null) {

                                Lattetude = location.getLatitude();
                                Longitude = location.getLongitude();
                            }
                        }
                    }
                }

            }


        } catch (Exception e) {
            e.printStackTrace();
        }

        return location;
    }

    public void stopUsingGPS() {
        if (locationManager != null) {

            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                // TODO: Consider calling
                //    ActivityCompat#requestPermissions
                // here to request the missing permissions, and then overriding
                //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
                //                                          int[] grantResults)
                // to handle the case where the user grants the permission. See the documentation
                // for ActivityCompat#requestPermissions for more details.
                return;
            }
            locationManager.removeUpdates(GPSFetching.this);
        }
    }

    public double getLatitude()
    {
        if (location != null)
        {
            Lattetude = location.getLatitude();

        }


        return  Lattetude;
    }

    public double getLongitude()
    {
        if (location != null)
        {
            Longitude = location.getLongitude();
        }

        return Longitude;
    }

    public boolean CanGetLocation()
    {
        return this.canGetLocation;
    }

    public void showSettingsAlert(final Home home)
    {
        AlertDialog.Builder alert = new AlertDialog.Builder(myContext);

        alert.setTitle("GPS settings");

        alert.setMessage("GPS not enabled. Do you want to go to settings menu? If you click cancel the weather won't appear");

        alert.setPositiveButton("Settings", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Global.okOrCancel = "OK";
                Intent intent = new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS);
               // Intent intent1 = new Intent(myContext,Home.class);

               // myContext.startActivity(intent1);
                myContext.startActivity(intent);
//                home.finish();
//                myContext.();



            }
        });

        alert.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Global.okOrCancel = "CANCEL";
                dialog.cancel();
            }
        });

        alert.show();
    }
    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onLocationChanged(Location location) {

    }

    @Override
    public void onStatusChanged(String provider, int status, Bundle extras) {

    }

    @Override
    public void onProviderEnabled(String provider) {

    }

    @Override
    public void onProviderDisabled(String provider) {

    }
}
