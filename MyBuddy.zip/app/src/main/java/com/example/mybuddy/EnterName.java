package com.example.mybuddy;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class EnterName extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_enter_name);

        final TextView name = (TextView) findViewById(R.id.name_text);
        Button button = (Button) findViewById(R.id.name_button);





        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (name.getText().toString().length() > 0)
                {
                    SharedPreferences.Editor editor2 = getSharedPreferences("MyBuddyPrefrences", MODE_PRIVATE).edit();
                    editor2.putString("name", name.getText().toString());
                    editor2.commit();

                    startActivity(new Intent(v.getContext(),Home.class));
                    ((Activity)v.getContext()).finish();
                }
            }
        });
    }
}
