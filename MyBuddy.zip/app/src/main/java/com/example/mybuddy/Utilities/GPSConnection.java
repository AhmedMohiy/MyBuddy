package com.example.mybuddy.Utilities;

import android.app.Activity;
import android.content.Context;
import android.os.AsyncTask;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.mybuddy.Models.MyDB;
import com.example.mybuddy.Models.ReceiveWeatherData;
import com.example.mybuddy.R;
import com.google.gson.Gson;

import java.util.Calendar;
import java.util.concurrent.ExecutionException;

/**
 * Created by ahmed on 13/11/16.
 */

public class GPSConnection extends AsyncTask<Context,Void,String> {

    static double Lat;
    static double Lon;

    Context context;
    @Override
    protected String doInBackground(Context... contexts) {

        GPSFetching gps = new GPSFetching(contexts[0]);

        context = contexts[0];

        String result = "";

        if (gps.CanGetLocation())
        {




             Lat = gps.getLatitude();
             Lon = gps.getLongitude();



            Global.Latitude = String.valueOf(Lat);
            Global.Longitude = String.valueOf(Lon);




            result = String.valueOf(Lat)+"|"+String.valueOf(Lon);






        }


        return  result;

    }

    @Override
    protected void onPostExecute(String s) {
        super.onPostExecute(s);


        TextView weatherTitle = (TextView) Global.HomeView.findViewById(R.id.home_weather_textview_weather_title);
        TextView weatherNow = (TextView) Global.HomeView.findViewById(R.id.home_weather_textview_big_degree);
        TextView weatherMax = (TextView) Global.HomeView.findViewById(R.id.home_weather_textview_max_degree);
        TextView weatherMin = (TextView) Global.HomeView.findViewById(R.id.home_weather_textview_min_degree);
        TextView City = (TextView) Global.HomeView.findViewById(R.id.home_country_text);


        ImageView imageView = (ImageView) Global.HomeView.findViewById(R.id.home_weather_image);

        Calendar now = Calendar.getInstance();

        int dayNum = now.get(Calendar.DAY_OF_MONTH);
        int month = now.get(Calendar.MONTH);
        int year = now.get(Calendar.YEAR);



        MyDB db = new MyDB(context,null,null,1);



        String wheaterDataString= "";
        Log.d("RESULT",s);
        if (s.length() > 0)
        {
            Lat = Double.parseDouble(s.substring(0,s.indexOf("|")));
            Lon = Double.parseDouble(s.substring(s.indexOf("|")+1));


            try {
                wheaterDataString = new Connection().execute(Lat+"",Lon+"").get();
            } catch (Exception e) {
                ((Activity) context).finish();
            }


            Gson gson = new Gson();
            ReceiveWeatherData data = gson.fromJson(wheaterDataString,ReceiveWeatherData.class);

            weatherTitle.setText(data.weather.get(0).main);
            weatherNow.setText((String.valueOf(data.main.temp)+(char) 0x00B0));
            weatherMin.setText((String.valueOf(data.main.temp_min)+(char) 0x00B0));
            weatherMax.setText((String.valueOf(data.main.temp_max)+(char) 0x00B0));
            City.setText(data.name);

            int imageID;

            if (data.weather.get(0).main.equals("Clear"))
            {
                imageID = context.getResources().getIdentifier("com.example.mybuddy:drawable/" + "art_clear", null, null);

            }
            else if(data.weather.get(0).main.equals("Clouds"))
            {
                imageID = context.getResources().getIdentifier("com.example.mybuddy:drawable/" + "art_clouds", null, null);

            }
            else if (data.weather.get(0).main.equals("Snow"))
            {
                imageID = context.getResources().getIdentifier("com.example.mybuddy:drawable/" + "art_snow", null, null);

            }
            else if (data.weather.get(0).main.equals("Rain"))
            {
                imageID = context.getResources().getIdentifier("com.example.mybuddy:drawable/" + "art_light_rain", null, null);

            }
            else
            {
                imageID = context.getResources().getIdentifier("com.example.mybuddy:drawable/" + "art_fog", null, null);

            }

            imageView.setImageResource(imageID);
            db.insertWeather(dayNum+"",month+"",year+"",Lat+"",Lon+"",data);

        }





    }
}
