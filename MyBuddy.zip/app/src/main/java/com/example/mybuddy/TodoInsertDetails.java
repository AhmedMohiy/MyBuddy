package com.example.mybuddy;


import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.graphics.Typeface;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

import com.example.mybuddy.Adapters.SpinnerCustomAdapter;
import com.example.mybuddy.Models.Data.Todo;
import com.example.mybuddy.Models.MyDB;
import com.example.mybuddy.Utilities.Global;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

import javax.microedition.khronos.opengles.GL;

public class TodoInsertDetails extends Activity {

    SpinnerCustomAdapter adapterHours;
    SpinnerCustomAdapter adapterMinutes;



    Context HomeContex;


    Spinner spinnerHours;
    Spinner spinnerMinutes;



    EditText Title;
    AutoCompleteTextView description;

    TextView hours_label;
    TextView minutes_lable;

    Button add;
    Button cancel;

    String hours = "";
    String minutes = "";

    String daystr ;
    String monstr ;





    MyDB db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_todo_insert_details);

        spinnerHours = (Spinner) findViewById(R.id.todo_details_spinner_hours);
        spinnerMinutes = (Spinner) findViewById(R.id.todo_details_spinner_minutes);

        Title = (EditText) findViewById(R.id.todo_details_title);
        description = (AutoCompleteTextView) findViewById(R.id.todo_details_specifications);
        add = (Button) findViewById(R.id.todo_details_button_add);
        cancel = (Button) findViewById(R.id.todo_details_button_cancel);


        hours_label = (TextView) findViewById(R.id.todo_details_hours_label);
        minutes_lable = (TextView) findViewById(R.id.todo_details_minutes_label);

        TextView title = (TextView) findViewById(R.id.insert_title);
        Typeface typeface = Typeface.createFromAsset(getAssets(),"Fonts/Bulldozer.ttf");
        title.setTypeface(typeface);


        HomeContex = Global.homeContext;

        Resources resources = getResources();

        ArrayList<String> Hours = new ArrayList<>();

        final ArrayList<String> Minutes = new ArrayList<>();


        for (int i = 0 ; i < 24 ; i++)
        {
            String str = i+"";

            if (str.length() == 1)
            {
                str = "0"+str;
            }

            Hours.add(str);
        }


        for (int i = 0 ; i < 60 ; i++)
        {
            String str = i+"";

            if (str.length() == 1)
            {
                str = "0"+str;
            }

            Minutes.add(str);
        }

        adapterHours = new SpinnerCustomAdapter(this,R.layout.spinner_layout,Hours,resources);


        adapterMinutes = new SpinnerCustomAdapter(this,R.layout.spinner_layout,Minutes,resources);


//        adapterHours.setDropDownViewResource(R.layout.spinner_dropdown_layout);
//        adapterMinutes.setDropDownViewResource(R.layout.spinner_dropdown_layout);


        spinnerHours.setAdapter(adapterHours);
        spinnerMinutes.setAdapter(adapterMinutes);

        spinnerHours.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                hours = parent.getItemAtPosition(position).toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        spinnerMinutes.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                minutes = parent.getItemAtPosition(position).toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        db = new MyDB(this,null,null,1);


        Calendar now = Calendar.getInstance();

        int dayNum = now.get(Calendar.DAY_OF_MONTH);
        int month = now.get(Calendar.MONTH);
        final int year = now.get(Calendar.YEAR);

         daystr = dayNum+"";
         monstr = month+"";

        if (daystr.length() == 1)
        {
            daystr = "0"+daystr;
        }


        if (monstr.length() == 1)
        {
            monstr = "0"+monstr;
        }



        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("EEE");
        Date date = new Date();
        final String dayOfTheWeek = simpleDateFormat.format(date);



        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String t = Title.getText().toString();
                String s = description.getText().toString();


                if(Title.getText().toString().length() > 0 && description.getText().toString().length() > 0
                        && hours.length() > 0 && minutes.length() > 0 )
                {

                    Todo todo = new Todo();

                    todo.TITLE = Title.getText().toString();
                    todo.DESCRIPTION = description.getText().toString();
                    todo.DAY_NUMBER = daystr;
                    todo.DAY_NAME = dayOfTheWeek;
                    todo.MONTH = monstr;
                    todo.YEAR = String.valueOf(year);
                    todo.BOOL_DONE = 0;

                    db.InsertTodo(todo);

                    startActivity(new Intent(v.getContext(),Home.class));

                    ((AppCompatActivity) HomeContex).finish();
                    ((Activity)v.getContext()).finish();






                }
                else
                {
                    Title.setBackground(Title.getText().toString().length()==0?getDrawable(R.drawable.error):getDrawable(R.drawable.edit_text_transparent));
                    description.setBackground(description.getText().toString().length()==0?

                            getDrawable(R.drawable.error):
                            getDrawable(R.drawable.edit_text_transparent_2)
                    );

                    hours_label.setBackground(hours.length() == 0?

                            getDrawable(R.drawable.error):
                            getDrawable(R.color.transparent)
                    );

                    minutes_lable.setBackground(minutes.length() == 0?

                            getDrawable(R.drawable.error):
                            getDrawable(R.color.transparent)
                    );

                }
            }
        });


        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ((Activity)v.getContext()).finish();
            }
        });


    }
}
