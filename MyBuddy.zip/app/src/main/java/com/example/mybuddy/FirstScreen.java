package com.example.mybuddy;

import android.content.Intent;
import android.graphics.Typeface;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.example.mybuddy.Utilities.Global;

public class FirstScreen extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_first_screen);

        final Animation animCycle = AnimationUtils.loadAnimation(this, R.anim.cycle);

        final LinearLayout linearLayout = (LinearLayout) findViewById(R.id.layout_first);
        linearLayout.setVisibility(View.GONE);

        TextView text = (TextView) findViewById(R.id.text_first);

        Typeface typeface = Typeface.createFromAsset(getAssets(),"Fonts/Jurassic.ttf");
        text.setTypeface(typeface);

        Global.InisializeMonthArray(this.getApplicationContext());

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                linearLayout.setVisibility(View.VISIBLE);
                linearLayout.startAnimation(animCycle);
            }
        }, 50);



        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {


//                if (Static.checkInternet(getBaseContext()))
//                {
//                    Static.connectionStatus = true;
//                    startActivity(new Intent(FirstScrean.this, Home.class));
//                    finish();
//                }else
//                {
//                    Static.favorite = true;
//                    Static.connectionStatus = false;
//                    startActivity(new Intent(FirstScrean.this, Home.class));
//                    finish();
//                }


                startActivity(new Intent(FirstScreen.this, Home.class));
                finish();

            }
        }, 3000);



    }
}
