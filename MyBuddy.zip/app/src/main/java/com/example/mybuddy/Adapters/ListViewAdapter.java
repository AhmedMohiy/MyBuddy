package com.example.mybuddy.Adapters;

import android.content.Context;
import android.support.annotation.NonNull;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import com.example.mybuddy.Models.Data.Memos;
import com.example.mybuddy.R;
import com.example.mybuddy.Utilities.Global;

import java.util.ArrayList;

/**
 * Created by ahmed on 04/11/16.
 */

public class ListViewAdapter extends ArrayAdapter<Memos> {

    private static class ViewHolder
    {
        TextView title;
        TextView time;
        TextView date;
    }

    public  ListViewAdapter(Context context, ArrayList<Memos> memo)
    {
        super(context, R.layout.reminder_row, memo);

    }

    @NonNull
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        Memos memos = getItem(position);
        ViewHolder viewHolder;

        if (convertView == null)
        {
            viewHolder = new ViewHolder();
            LayoutInflater inflater = LayoutInflater.from(getContext());
            convertView = inflater.inflate(R.layout.reminder_row, parent, false);

            viewHolder.title = (TextView) convertView.findViewById(R.id.reminder_row_title);
            viewHolder.date = (TextView) convertView.findViewById(R.id.reminder_row_date);
            viewHolder.time = (TextView) convertView.findViewById(R.id.reminder_row_time);

            convertView.setTag(viewHolder);

        }
        else
        {
            viewHolder = (ViewHolder) convertView.getTag();



        }

        viewHolder.title.setText(memos.SPECIFICATION);

        String str = Global.month[Integer.parseInt(memos.MONTH)].substring(0,3)+" "+
                memos.DAY+", "+memos.YEAR;

        viewHolder.date.setText(str);

        viewHolder.time.setText(memos.HOURS+":"+memos.MINUTES);

        return convertView;
    }
}
