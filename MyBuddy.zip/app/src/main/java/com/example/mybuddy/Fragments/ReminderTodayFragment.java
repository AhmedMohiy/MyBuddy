package com.example.mybuddy.Fragments;

import android.app.Fragment;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.LinearLayout;
import android.widget.ListView;

import com.example.mybuddy.Adapters.ListViewAdapter;
import com.example.mybuddy.Models.Data.Memos;
import com.example.mybuddy.Models.MyDB;
import com.example.mybuddy.R;
import com.example.mybuddy.Utilities.Global;

import java.util.ArrayList;
import java.util.Calendar;

/**
 * Created by ahmed on 04/11/16.
 */

public class ReminderTodayFragment extends Fragment {

    View view;

    MyDB db;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        view = inflater.inflate(R.layout.reminder_today_fragment,container,false);


        getActivity().setTitle(this.getResources().getString(R.string.reminderToday));

        setHasOptionsMenu(true);

        Calendar now = Calendar.getInstance();

        int dayNum = now.get(Calendar.DAY_OF_MONTH);
        int month = now.get(Calendar.MONTH);
        int year = now.get(Calendar.YEAR);


        String Daystr = dayNum+"";
        String Monthstr = month+"";

        if (Daystr.length() == 1)
        {
            Daystr = "0"+Daystr;
        }

        if (Monthstr.length() ==1 )
        {
            Monthstr = "0"+Monthstr;
        }

        db = new MyDB(getActivity(),null,null,1);

        ArrayList<Memos> memoses = db.getMemosByDay(Daystr,year+"",Monthstr);

        ListView myList = (ListView) view.findViewById(R.id.List_view_reminder);

        LinearLayout layout = (LinearLayout) view.findViewById(R.id.reminder_fragment_layout);

        ListViewAdapter adapter = new ListViewAdapter(getActivity(),memoses);

        myList.setAdapter(adapter);

        final Animation animCycle = AnimationUtils.loadAnimation(view.getContext(), R.anim.anothercycle);

        if (memoses.size() == 0)
        {
            layout.setVisibility(View.VISIBLE);
            layout.startAnimation(animCycle);
        }
        else
        {
            layout.setVisibility(View.GONE);
        }

        Global.fab.setVisibility(View.INVISIBLE);
        return view;
    }

}
