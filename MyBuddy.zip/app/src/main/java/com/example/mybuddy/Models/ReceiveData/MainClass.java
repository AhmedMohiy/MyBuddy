package com.example.mybuddy.Models.ReceiveData;

/**
 * Created by ahmed on 04/11/16.
 */

public class MainClass {

    public double temp = 0.0;
    public double temp_min = 0.0;
    public double temp_max = 0.0;



}
